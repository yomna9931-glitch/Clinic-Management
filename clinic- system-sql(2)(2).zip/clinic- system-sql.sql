DROP DATABASE IF EXISTS clinic_management;
CREATE DATABASE clinic_management;
USE clinic_management;

CREATE TABLE Departments (
    department_id INT PRIMARY KEY AUTO_INCREMENT,
    department_name VARCHAR(100) NOT NULL
);

CREATE TABLE Doctors (
    doctor_id INT PRIMARY KEY AUTO_INCREMENT,
    doctor_name VARCHAR(100) NOT NULL,
    specialization VARCHAR(100),
    department_id INT,
    FOREIGN KEY (department_id) REFERENCES Departments(department_id)
);

CREATE TABLE Patients (
    patient_id INT PRIMARY KEY AUTO_INCREMENT,
    patient_name VARCHAR(100) NOT NULL,
    age INT CHECK(age > 0),
    gender VARCHAR(10),
    phone VARCHAR(20)
);

CREATE TABLE Appointments (
    appointment_id INT PRIMARY KEY AUTO_INCREMENT,
    patient_id INT,
    doctor_id INT,
    appointment_date DATETIME,
    status VARCHAR(20),
    FOREIGN KEY (patient_id) REFERENCES Patients(patient_id),
    FOREIGN KEY (doctor_id) REFERENCES Doctors(doctor_id)
);

CREATE TABLE Medical_Records (
    record_id INT PRIMARY KEY AUTO_INCREMENT,
    patient_id INT,
    diagnosis VARCHAR(255),
    visit_date DATE,
    FOREIGN KEY (patient_id) REFERENCES Patients(patient_id)
);

CREATE TABLE Prescriptions (
    prescription_id INT PRIMARY KEY AUTO_INCREMENT,
    record_id INT,
    medicine_name VARCHAR(100),
    dosage VARCHAR(100),
    FOREIGN KEY (record_id) REFERENCES Medical_Records(record_id)
);

INSERT INTO Departments (department_name) VALUES
('Cardiology'),
('Neurology'),
('Dermatology'),
('Orthopedics'),
('Pediatrics');

INSERT INTO Doctors (doctor_name, specialization, department_id) VALUES
('Ahmed Hassan', 'Cardiologist', 1),
('Mona Ali', 'Neurologist', 2),
('Khaled Omar', 'Dermatologist', 3),
('Sara Mostafa', 'Orthopedic', 4),
('Youssef Adel', 'Pediatrician', 5);

INSERT INTO Patients (patient_name, age, gender, phone) VALUES
('Omar Tarek', 22, 'Male', '01012345678'),
('Mariam Samy', 20, 'Female', '01198765432'),
('Ali Mohamed', 35, 'Male', '01255555555'),
('Nour Ahmed', 28, 'Female', '01077777777'),
('Salma Adel', 19, 'Female', '01122222222');

INSERT INTO Appointments (patient_id, doctor_id, appointment_date, status) VALUES
(1, 1, '2026-06-05 10:00:00', 'Completed'),
(2, 2, '2026-06-06 11:00:00', 'Pending'),
(3, 3, '2026-06-07 12:00:00', 'Completed'),
(4, 4, '2026-06-08 01:00:00', 'Cancelled'),
(5, 5, '2026-06-09 02:00:00', 'Pending');

INSERT INTO Medical_Records (patient_id, diagnosis, visit_date) VALUES
(1, 'High Blood Pressure', '2026-05-25'),
(3, 'Skin Allergy', '2026-05-26');

INSERT INTO Prescriptions (record_id, medicine_name, dosage) VALUES
(1, 'Panadol', '2 times daily'),
(2, 'Skin Cream', 'Once daily');

ALTER TABLE Appointments 
ADD CONSTRAINT chk_status 
CHECK (Status IN ('Pending', 'Completed', 'Cancelled'));

DELIMITER $$

CREATE TRIGGER prevent_double_booking
BEFORE INSERT ON Appointments
FOR EACH ROW
BEGIN
    IF EXISTS (
        SELECT 1
        FROM Appointments
        WHERE Doctor_id = NEW.Doctor_id
          AND Appointment_date = NEW.Appointment_date
    ) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Doctor already has an appointment';
    END IF;
END$$

CREATE TRIGGER auto_create_medical_record
AFTER UPDATE ON Appointments
FOR EACH ROW
BEGIN
    IF NEW.Status = 'Completed' AND OLD.Status <> 'Completed' THEN
        INSERT INTO Medical_Records (Patient_id, Diagnosis, Visit_date)
        VALUES (NEW.Patient_id, 'Pending Diagnosis', CURDATE());
    END IF;
END$$

DELIMITER ;

CREATE VIEW Doctor_Upcoming_Appointments AS
SELECT
    d.doctor_id,
    d.doctor_name,
    COUNT(a.appointment_id) AS appointment_count
FROM Doctors d
INNER JOIN Appointments a
    ON d.doctor_id = a.doctor_id
WHERE a.appointment_date BETWEEN NOW()
      AND DATE_ADD(NOW(), INTERVAL 1 MONTH)
GROUP BY d.doctor_id, d.doctor_name;

SELECT * FROM Patients;

SELECT Doctors.doctor_name, Doctors.specialization, Departments.department_name
FROM Doctors
JOIN Departments ON Doctors.department_id = Departments.department_id;

SELECT Doctors.doctor_name, COUNT(Appointments.appointment_id) AS total_appointments
FROM Doctors
LEFT JOIN Appointments ON Doctors.doctor_id = Appointments.doctor_id
GROUP BY Doctors.doctor_name;

SELECT * FROM Appointments WHERE status = 'Completed';

SELECT AVG(age) AS average_age FROM Patients;

SELECT patient_name, age 
FROM Patients 
WHERE age > (SELECT AVG(age) FROM Patients);

SELECT * FROM Doctors ORDER BY doctor_name ASC;

SELECT gender, COUNT(*) AS total_patients 
FROM Patients 
GROUP BY gender;

SELECT Patients.patient_name, Doctors.doctor_name, Appointments.appointment_date, Appointments.status
FROM Appointments
JOIN Patients ON Appointments.patient_id = Patients.patient_id
JOIN Doctors ON Appointments.doctor_id = Doctors.doctor_id;

SELECT DISTINCT Patients.patient_name
FROM Patients
JOIN Medical_Records ON Patients.patient_id = Medical_Records.patient_id;

SELECT * FROM Doctor_Upcoming_Appointments;